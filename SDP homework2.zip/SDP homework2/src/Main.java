public class Main {
    public static void main(String[] args) {
        Notification emailNotification = new EmailNotification();
        Notification SMSNotification = new SMSNotification(emailNotification);
        sendNotification(SMSNotification);
    }

    private static void sendNotification(Notification notification) {
        notification.send();
    }
}
