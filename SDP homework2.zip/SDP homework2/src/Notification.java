public interface Notification {
    void send();
}
